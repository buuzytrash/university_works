#include "tinylang/CodeGen/CGModule.h"
#include "tinylang/CodeGen/CGProcedure.h"
#include "llvm/ADT/StringExtras.h"
#include "llvm/Support/CommandLine.h"

using namespace tinylang;

static llvm::cl::opt<bool>
    Debug("g", llvm::cl::desc("Generate debug information"),
          llvm::cl::init(false));

CGModule::CGModule(ASTContext &ASTCtx, llvm::Module *M)
    : ASTCtx(ASTCtx), M(M), TBAA(CGTBAA(*this)) {
  initialize();
}

void CGModule::initialize() {
  VoidTy = llvm::Type::getVoidTy(getLLVMCtx());
  Int1Ty = llvm::Type::getInt1Ty(getLLVMCtx());
  Int32Ty = llvm::Type::getInt32Ty(getLLVMCtx());
  Int64Ty = llvm::Type::getInt64Ty(getLLVMCtx());
  Int32Zero =
      llvm::ConstantInt::get(Int32Ty, 0, /*isSigned*/ true);
  if (Debug)
    DebugInfo.reset(new CGDebugInfo(*this));
}

llvm::Type *CGModule::convertType(TypeDeclaration *Ty) {
  if (llvm::Type *T = TypeCache[Ty])
    return T;

  if (llvm::isa<PervasiveTypeDeclaration>(Ty)) {
    if (Ty->getName() == "INTEGER")
      return Int64Ty;
    if (Ty->getName() == "BOOLEAN")
      return Int1Ty;
  } else if (auto *AliasTy =
                 llvm::dyn_cast<AliasTypeDeclaration>(Ty)) {
    llvm::Type *T = convertType(AliasTy->getType());
    return TypeCache[Ty] = T;
  } else if (auto *ArrayTy =
                 llvm::dyn_cast<ArrayTypeDeclaration>(Ty)) {
    llvm::Type *Component =
        convertType(ArrayTy->getType());
    // The semantic analysis makes sure that the Nums
    // expression is a constant expression of type
    // INTEGER. To simplify the coding, we expect an
    // IntegerLiteral here.
    // TODO Evaluate the constant expression.
    Expr *Nums = ArrayTy->getNums();
    assert(llvm::cast<IntegerLiteral>(Nums) &&
           "Expected an integer literal");
    uint64_t NumElements =
        llvm::cast<IntegerLiteral>(Nums)
            ->getValue()
            .getZExtValue();
    llvm::Type *T =
        llvm::ArrayType::get(Component, NumElements);
    return TypeCache[Ty] = T;
  } else if (auto *RecordTy =
                 llvm ::dyn_cast<RecordTypeDeclaration>(
                     Ty)) {
    llvm::SmallVector<llvm::Type *, 4> Elements;
    for (const auto &F : RecordTy->getFields()) {
      Elements.push_back(convertType(F.getType()));
    }
    llvm::Type *T = llvm::StructType::create(
        Elements, RecordTy->getName(), false);
    return TypeCache[Ty] = T;
  }
  llvm::report_fatal_error("Unsupported type");
}

std::string CGModule::mangleName(Decl *D) {
  std::string Mangled;
  llvm::SmallString<16> Tmp;
  while (D) {
    llvm::StringRef Name = D->getName();
    Tmp.clear();
    Tmp.append(llvm::itostr(Name.size()));
    Tmp.append(Name);
    Mangled.insert(0, Tmp.c_str());
    D = D->getEnclosingDecl();
  }
  Mangled.insert(0, "_t");
  return Mangled;
}

void CGModule::decorateInst(llvm::Instruction *Inst,
                            TypeDeclaration *Type) {
  if (auto *N = TBAA.getAccessTagInfo(Type))
    Inst->setMetadata(llvm::LLVMContext::MD_tbaa, N);
}

llvm::GlobalObject *CGModule::getGlobal(Decl *D) {
  return Globals[D];
}

void CGModule::applyLocation(llvm::Instruction *Inst,
                             llvm::SMLoc Loc) {
  if (CGDebugInfo *Dbg = getDbgInfo())
    Inst->setDebugLoc(Dbg->getDebugLoc(Loc));
}

void CGModule::run(ModuleDeclaration *Mod) {
  this->Mod = Mod;
  for (auto *Decl : Mod->getDecls()) {
    if (auto *Var =
            llvm::dyn_cast<VariableDeclaration>(Decl)) {
      // Create global variables
      llvm::GlobalVariable *V = new llvm::GlobalVariable(
          *M, convertType(Var->getType()),
          /*isConstant=*/false,
          llvm::GlobalValue::PrivateLinkage, nullptr,
          mangleName(Var));
      Globals[Var] = V;
      if (CGDebugInfo *Dbg = getDbgInfo())
        Dbg->emitGlobalVariable(Var, V);
    } else if (auto *Proc =
                   llvm::dyn_cast<ProcedureDeclaration>(
                       Decl)) {
      CGProcedure CGP(*this);
      CGP.run(Proc);
    }
  }
  if (CGDebugInfo *Dbg = getDbgInfo())
    Dbg->finalize();
}
