#include <unistd.h>
#include <stdio.h>

int main()
{
    int pid = getpid();

    printf("PID: %d\n", pid);
    return 0;
}